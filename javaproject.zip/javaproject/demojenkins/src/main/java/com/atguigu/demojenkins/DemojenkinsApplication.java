package com.atguigu.demojenkins;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemojenkinsApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemojenkinsApplication.class, args);
    }

}
